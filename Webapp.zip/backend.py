"""
Dataiku Standard Web App — Python backend
=========================================

Paste this into the *Python* tab of a Dataiku "Standard" (code) web app. The
`app` object is provided by Dataiku; you only add routes.

No file storage
---------------
Uploaded files are parsed into pandas DataFrames held in an in-memory session
store keyed by a random token, with a TTL. Nothing is written to disk or to a
Dataiku dataset. Sessions self-evict after `SESSION_TTL_SECONDS` or when the
user finishes/exports. If the backend process restarts, all sessions vanish —
which is exactly the "temporary uploads only" behaviour requested.

Frontend calls these routes via `getWebAppBackendUrl('/route')`.

Requires in the code env: pandas, numpy, openpyxl. rapidfuzz recommended.
Put reconcile_engine.py alongside this file (or paste it above these routes).
"""

import io
import time
import uuid
import threading
from typing import Dict, Any, List, Tuple

import pandas as pd
from flask import request, jsonify, send_file

# When deployed in Dataiku, keep reconcile_engine.py in the project libs
# (Application menu > Libraries > python/) or paste its contents above this line.
from reconcile_engine import (
    Field, NormalizationConfig, FuzzyConfig, reconcile,
    ROLE_KEY, ROLE_VALUE, DTYPE_NUMERIC, DTYPE_TEXT, DTYPE_DATE,
    fuzzy_backend,
)

# --------------------------------------------------------------------------- #
# In-memory, TTL'd session store (no persistence)
# --------------------------------------------------------------------------- #
SESSION_TTL_SECONDS = 60 * 60          # 1 hour
MAX_PREVIEW_ROWS = 200                  # never ship the whole file to the browser
MAX_UPLOAD_MB = 100                     # soft guard per request

_SESSIONS: Dict[str, Dict[str, Any]] = {}
_LOCK = threading.Lock()


def _now() -> float:
    return time.time()


def _evict_expired() -> None:
    cutoff = _now() - SESSION_TTL_SECONDS
    with _LOCK:
        for sid in [s for s, v in _SESSIONS.items() if v["ts"] < cutoff]:
            _SESSIONS.pop(sid, None)


def _get_session(sid: str) -> Dict[str, Any]:
    _evict_expired()
    with _LOCK:
        s = _SESSIONS.get(sid)
        if s is None:
            raise KeyError("Unknown or expired session")
        s["ts"] = _now()
        return s


def _new_session() -> str:
    sid = uuid.uuid4().hex
    with _LOCK:
        _SESSIONS[sid] = {"ts": _now(), "left": [], "right": [], "result": None}
    return sid


def _read_upload(fs) -> pd.DataFrame:
    name = (fs.filename or "").lower()
    data = fs.read()
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise ValueError(f"{fs.filename} exceeds {MAX_UPLOAD_MB} MB")
    bio = io.BytesIO(data)
    if name.endswith((".xlsx", ".xlsm", ".xls")):
        return pd.read_excel(bio, dtype=object)
    # default: CSV/TSV, sniff separator
    sep = "\t" if name.endswith((".tsv", ".txt")) else None
    return pd.read_csv(bio, dtype=object, sep=sep, engine="python")


# --------------------------------------------------------------------------- #
# Routes
# --------------------------------------------------------------------------- #
@app.route("/session", methods=["POST"])
def create_session():
    return jsonify({"session_id": _new_session(), "fuzzy_backend": fuzzy_backend()})


@app.route("/upload", methods=["POST"])
def upload():
    """Accept many files for one side. Body: form-data sid, side, files[]."""
    sid = request.form.get("sid", "")
    side = request.form.get("side", "")
    if side not in ("left", "right"):
        return jsonify({"error": "side must be 'left' or 'right'"}), 400
    try:
        s = _get_session(sid)
    except KeyError as e:
        return jsonify({"error": str(e)}), 404

    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "no files provided"}), 400

    added = []
    for fs in files:
        try:
            df = _read_upload(fs)
        except Exception as e:
            return jsonify({"error": f"could not read {fs.filename}: {e}"}), 400
        s[side].append((fs.filename, df))
        added.append({
            "filename": fs.filename,
            "rows": int(len(df)),
            "columns": [str(c) for c in df.columns],
        })

    # union of columns across all files on this side (for mapping UI)
    all_cols: List[str] = []
    for _, df in s[side]:
        for c in df.columns:
            if str(c) not in all_cols:
                all_cols.append(str(c))

    # small preview from the first file
    preview = []
    if s[side]:
        first = s[side][0][1].head(min(MAX_PREVIEW_ROWS, 20))
        preview = first.astype(object).where(pd.notna(first), None).to_dict("records")

    return jsonify({
        "side": side,
        "files": added,
        "side_columns": all_cols,
        "side_file_count": len(s[side]),
        "preview": preview,
    })


@app.route("/reset_side", methods=["POST"])
def reset_side():
    body = request.get_json(force=True)
    try:
        s = _get_session(body.get("sid", ""))
    except KeyError as e:
        return jsonify({"error": str(e)}), 404
    side = body.get("side")
    if side in ("left", "right"):
        s[side] = []
    return jsonify({"ok": True})


def _build_fields(field_specs: List[Dict[str, Any]]) -> List[Field]:
    fields: List[Field] = []
    for fs in field_specs:
        fields.append(Field(
            name=fs["name"],
            role=fs["role"],
            dtype=fs.get("dtype", DTYPE_TEXT),
            left_source=fs.get("left_source"),
            right_source=fs.get("right_source"),
            abs_tol=float(fs.get("abs_tol", 0.0) or 0.0),
            rel_tol=float(fs.get("rel_tol", 0.0) or 0.0),
            text_fuzzy_threshold=(
                float(fs["text_fuzzy_threshold"])
                if fs.get("text_fuzzy_threshold") not in (None, "") else None
            ),
            agg=fs.get("agg", "sum"),
        ))
    return fields


@app.route("/reconcile", methods=["POST"])
def run_reconcile():
    """Body: { sid, fields:[...], fuzzy:{enabled,threshold,blocking_field}, norm:{...} }."""
    body = request.get_json(force=True)
    try:
        s = _get_session(body.get("sid", ""))
    except KeyError as e:
        return jsonify({"error": str(e)}), 404

    if not s["left"] or not s["right"]:
        return jsonify({"error": "upload files on both sides first"}), 400

    try:
        fields = _build_fields(body.get("fields", []))
    except Exception as e:
        return jsonify({"error": f"invalid field config: {e}"}), 400
    if not any(f.role == ROLE_KEY for f in fields):
        return jsonify({"error": "at least one key field is required"}), 400

    fz = body.get("fuzzy", {})
    fuzzy = FuzzyConfig(
        enabled=bool(fz.get("enabled", True)),
        threshold=float(fz.get("threshold", 90.0)),
        blocking_field=fz.get("blocking_field") or None,
        blocking_prefix_len=int(fz.get("blocking_prefix_len", 0) or 0),
    )
    nm = body.get("norm", {})
    norm = NormalizationConfig(
        casefold_keys=bool(nm.get("casefold_keys", True)),
        drop_exact_duplicates=bool(nm.get("drop_exact_duplicates", True)),
        dayfirst=bool(nm.get("dayfirst", False)),
    )

    try:
        result = reconcile(s["left"], s["right"], fields, norm=norm, fuzzy=fuzzy)
    except Exception as e:
        return jsonify({"error": f"reconciliation failed: {e}"}), 500

    s["result"] = result  # held in memory only, for export

    def cap(df):
        return df.head(MAX_PREVIEW_ROWS)

    payload = result.as_dict()
    # cap previews sent to the browser; full data stays server-side for export
    for k in ("reconciled", "breaks", "unmatched_left", "unmatched_right"):
        payload[k] = payload[k][:MAX_PREVIEW_ROWS]
    payload["truncated"] = {
        "reconciled": len(result.reconciled) > MAX_PREVIEW_ROWS,
        "breaks": len(result.breaks) > MAX_PREVIEW_ROWS,
        "unmatched_left": len(result.unmatched_left) > MAX_PREVIEW_ROWS,
        "unmatched_right": len(result.unmatched_right) > MAX_PREVIEW_ROWS,
    }
    return jsonify(payload)


@app.route("/export", methods=["GET"])
def export():
    """Stream the full result as a multi-sheet XLSX from memory (no disk)."""
    sid = request.args.get("sid", "")
    try:
        s = _get_session(sid)
    except KeyError as e:
        return jsonify({"error": str(e)}), 404
    result = s.get("result")
    if result is None:
        return jsonify({"error": "run a reconciliation first"}), 400

    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        pd.DataFrame([result.summary]).to_excel(xw, sheet_name="summary", index=False)
        result.field_variance.to_excel(xw, sheet_name="field_variance", index=False)
        result.breaks.to_excel(xw, sheet_name="breaks", index=False)
        result.reconciled.to_excel(xw, sheet_name="reconciled", index=False)
        result.unmatched_left.to_excel(xw, sheet_name="unmatched_left", index=False)
        result.unmatched_right.to_excel(xw, sheet_name="unmatched_right", index=False)
    buf.seek(0)
    return send_file(
        buf, as_attachment=True, download_name="reconciliation.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.route("/finish", methods=["POST"])
def finish():
    """Explicitly drop a session's data (belt-and-braces on top of TTL)."""
    body = request.get_json(force=True)
    with _LOCK:
        _SESSIONS.pop(body.get("sid", ""), None)
    return jsonify({"ok": True})
