/* Paste into the JS tab of a Dataiku Standard web app.
   Uses getWebAppBackendUrl(), a global Dataiku provides. */
(function () {
  const api = (p) => (typeof getWebAppBackendUrl === "function"
    ? getWebAppBackendUrl(p) : p);

  const state = { sid: null, leftCols: [], rightCols: [], fieldRows: 0 };
  const $ = (id) => document.getElementById(id);

  // ---- session ----
  async function initSession() {
    const r = await fetch(api("/session"), { method: "POST" });
    const d = await r.json();
    state.sid = d.session_id;
    $("rc-backend").textContent = "fuzzy: " + d.fuzzy_backend;
    addFieldRow(); // start with one blank field
  }

  // ---- uploads ----
  async function uploadSide(side, files) {
    const fd = new FormData();
    fd.append("sid", state.sid);
    fd.append("side", side);
    for (const f of files) fd.append("files", f);
    const r = await fetch(api("/upload"), { method: "POST", body: fd });
    const d = await r.json();
    if (d.error) { alert(d.error); return; }
    const list = $(side + "-list");
    d.files.forEach((f) => {
      const li = document.createElement("li");
      li.innerHTML = `<span>${f.filename}</span><span class="rc-muted">${f.rows} rows</span>`;
      list.appendChild(li);
    });
    if (side === "left") state.leftCols = d.side_columns;
    else state.rightCols = d.side_columns;
    refreshColumnPickers();
  }

  // ---- field mapping table ----
  function colOptions(cols, selected) {
    return ['<option value="">—</option>']
      .concat(cols.map((c) =>
        `<option ${c === selected ? "selected" : ""}>${c}</option>`)).join("");
  }

  function addFieldRow(preset) {
    preset = preset || {};
    const idx = state.fieldRows++;
    const tr = document.createElement("tr");
    tr.dataset.idx = idx;
    tr.innerHTML = `
      <td><input class="f-name" placeholder="e.g. amount" value="${preset.name||""}"></td>
      <td><select class="f-role">
        <option value="key">key</option>
        <option value="value" selected>value</option></select></td>
      <td><select class="f-dtype">
        <option value="text">text</option>
        <option value="numeric">numeric</option>
        <option value="date">date</option></select></td>
      <td><select class="f-left">${colOptions(state.leftCols, preset.left)}</select></td>
      <td><select class="f-right">${colOptions(state.rightCols, preset.right)}</select></td>
      <td><input class="f-abstol" type="number" step="any" placeholder="0"></td>
      <td><input class="f-reltol" type="number" step="any" placeholder="0"></td>
      <td><input class="f-fuzzy" type="number" min="0" max="100" placeholder="—"></td>
      <td><select class="f-agg">
        <option value="sum">sum</option><option value="mean">mean</option>
        <option value="first">first</option><option value="last">last</option>
        <option value="count">count</option><option value="max">max</option>
        <option value="min">min</option></select></td>
      <td><button class="rc-ghost rc-btn f-del">✕</button></td>`;
    tr.querySelector(".f-del").onclick = () => { tr.remove(); refreshBlockingOptions(); };
    tr.querySelector(".f-name").oninput = refreshBlockingOptions;
    tr.querySelector(".f-role").onchange = refreshBlockingOptions;
    $("fields-body").appendChild(tr);
    refreshBlockingOptions();
  }

  function refreshColumnPickers() {
    document.querySelectorAll("#fields-body tr").forEach((tr) => {
      const l = tr.querySelector(".f-left"), r = tr.querySelector(".f-right");
      l.innerHTML = colOptions(state.leftCols, l.value);
      r.innerHTML = colOptions(state.rightCols, r.value);
    });
  }

  function refreshBlockingOptions() {
    const keys = [];
    document.querySelectorAll("#fields-body tr").forEach((tr) => {
      if (tr.querySelector(".f-role").value === "key") {
        const n = tr.querySelector(".f-name").value.trim();
        if (n) keys.push(n);
      }
    });
    const sel = $("blocking-field");
    const cur = sel.value;
    sel.innerHTML = '<option value="">— none —</option>' +
      keys.map((k) => `<option ${k === cur ? "selected" : ""}>${k}</option>`).join("");
  }

  function collectFields() {
    const out = [];
    document.querySelectorAll("#fields-body tr").forEach((tr) => {
      const name = tr.querySelector(".f-name").value.trim();
      if (!name) return;
      out.push({
        name,
        role: tr.querySelector(".f-role").value,
        dtype: tr.querySelector(".f-dtype").value,
        left_source: tr.querySelector(".f-left").value || null,
        right_source: tr.querySelector(".f-right").value || null,
        abs_tol: parseFloat(tr.querySelector(".f-abstol").value) || 0,
        rel_tol: (parseFloat(tr.querySelector(".f-reltol").value) || 0) / 100,
        text_fuzzy_threshold: tr.querySelector(".f-fuzzy").value || null,
        agg: tr.querySelector(".f-agg").value,
      });
    });
    return out;
  }

  // ---- run ----
  async function run() {
    const fields = collectFields();
    if (!fields.some((f) => f.role === "key")) { alert("Add at least one key field."); return; }
    $("run-status").textContent = "Running…";
    const body = {
      sid: state.sid,
      fields,
      fuzzy: {
        enabled: $("fuzzy-enabled").checked,
        threshold: parseFloat($("fuzzy-threshold").value) || 90,
        blocking_field: $("blocking-field").value || null,
      },
      norm: {
        casefold_keys: $("casefold-keys").checked,
        drop_exact_duplicates: $("drop-dupes").checked,
        dayfirst: $("dayfirst").checked,
      },
    };
    const r = await fetch(api("/reconcile"), {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const d = await r.json();
    $("run-status").textContent = "";
    if (d.error) { alert(d.error); return; }
    renderResults(d);
  }

  // ---- results rendering ----
  function metric(k, v, cls) {
    return `<div class="rc-metric ${cls||""}"><div class="v">${v}</div><div class="k">${k}</div></div>`;
  }

  function renderResults(d) {
    $("step-results").classList.remove("rc-hidden");
    const s = d.summary;
    $("summary-cards").innerHTML =
      metric("Reconciled", s.reconciled, "ok") +
      metric("Breaks", s.breaks, "break") +
      metric("Unmatched L", s.unmatched_left) +
      metric("Unmatched R", s.unmatched_right) +
      metric("Recon rate", s.reconciliation_rate + "%") +
      metric("Matched (exact/fuzzy)", s.matched_exact + " / " + s.matched_fuzzy);

    $("variance-table").innerHTML = tableHTML(d.field_variance);

    const tabs = [
      ["breaks", "Breaks (" + s.breaks + ")"],
      ["reconciled", "Reconciled (" + s.reconciled + ")"],
      ["unmatched_left", "Unmatched L (" + s.unmatched_left + ")"],
      ["unmatched_right", "Unmatched R (" + s.unmatched_right + ")"],
    ];
    const tb = $("result-tabs"); tb.innerHTML = "";
    tabs.forEach(([key, label], i) => {
      const b = document.createElement("div");
      b.className = "rc-tab" + (i === 0 ? " active" : "");
      b.textContent = label;
      b.onclick = () => {
        document.querySelectorAll(".rc-tab").forEach((x) => x.classList.remove("active"));
        b.classList.add("active");
        $("result-panel").innerHTML = tableHTML(d[key], key)
          + (d.truncated && d.truncated[key] ? '<p class="rc-muted">Preview capped — export for full data.</p>' : "");
      };
    });
    $("result-panel").innerHTML = tableHTML(d.breaks, "breaks");
  }

  function tableHTML(rows, kind) {
    if (!rows || !rows.length) return '<p class="rc-muted">Nothing here.</p>';
    const cols = Object.keys(rows[0]);
    const head = cols.map((c) => `<th>${c}</th>`).join("");
    const body = rows.map((row) => {
      const tds = cols.map((c) => {
        let v = row[c]; if (v === null || v === undefined) v = "";
        let cls = "";
        if (c.endsWith("__ok")) cls = v === true ? "cell-ok" : "cell-break";
        if (c === "match_type") return `<td><span class="rc-badge ${v}">${v}</span></td>`;
        return `<td class="${cls}">${v}</td>`;
      }).join("");
      return `<tr>${tds}</tr>`;
    }).join("");
    return `<table class="rc-datatable"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
  }

  function exportWorkbook() {
    window.location = api("/export") + "?sid=" + encodeURIComponent(state.sid);
  }

  // ---- wire up ----
  document.addEventListener("DOMContentLoaded", () => {
    $("left-files").onchange = (e) => uploadSide("left", e.target.files);
    $("right-files").onchange = (e) => uploadSide("right", e.target.files);
    $("add-field").onclick = () => addFieldRow();
    $("run-btn").onclick = run;
    $("export-btn").onclick = exportWorkbook;
    initSession();
  });
})();
