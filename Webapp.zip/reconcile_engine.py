"""
reconcile_engine.py
===================

A self-contained, dependency-light reconciliation engine.

Pipeline
--------
    raw files (many, per side)
        -> streamline()        normalize each file to a clean frame
        -> canonicalize()      map source cols -> canonical fields, collapse to key->value records
        -> match()             exact + fuzzy line-item matching across the two sides
        -> compare()           variance on the value fields the user chose
        -> ReconResult         reconciled / breaks / unmatched_left / unmatched_right + summary

Design goals
------------
* No disk persistence required. Everything operates on in-memory DataFrames.
* Config-driven. The caller (webapp backend) describes fields, roles, dtypes and
  tolerances; the engine has no hard-coded business schema.
* Graceful fuzzy backend: uses `rapidfuzz` if installed, else stdlib `difflib`.
* Deterministic, greedy fuzzy assignment so a left key is never double-matched.

Dependencies: pandas, numpy (both standard in a Dataiku code env). rapidfuzz optional.
"""

from __future__ import annotations

import re
import math
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

# --------------------------------------------------------------------------- #
# Fuzzy backend (rapidfuzz preferred, difflib fallback)
# --------------------------------------------------------------------------- #
try:
    from rapidfuzz import fuzz as _rf_fuzz

    _FUZZY_BACKEND = "rapidfuzz"

    def _similarity(a: str, b: str) -> float:
        """Return similarity in [0, 100]."""
        return float(_rf_fuzz.token_sort_ratio(a, b))

except Exception:  # pragma: no cover - exercised only when rapidfuzz absent
    from difflib import SequenceMatcher

    _FUZZY_BACKEND = "difflib"

    def _similarity(a: str, b: str) -> float:
        return SequenceMatcher(None, a, b).ratio() * 100.0


def fuzzy_backend() -> str:
    """Name of the active fuzzy backend, for diagnostics/UI."""
    return _FUZZY_BACKEND


# --------------------------------------------------------------------------- #
# Configuration objects
# --------------------------------------------------------------------------- #
DTYPE_NUMERIC = "numeric"
DTYPE_TEXT = "text"
DTYPE_DATE = "date"

ROLE_KEY = "key"
ROLE_VALUE = "value"

AGG_SUM = "sum"
AGG_MEAN = "mean"
AGG_FIRST = "first"
AGG_LAST = "last"
AGG_COUNT = "count"
AGG_MAX = "max"
AGG_MIN = "min"


@dataclass
class Field:
    """One canonical field shared across both sides.

    A canonical field has a single logical name (e.g. "invoice_id" or "amount")
    but may come from differently-named columns on each side. `left_source` and
    `right_source` name the raw column on each side.
    """
    name: str                       # canonical name
    role: str                       # ROLE_KEY | ROLE_VALUE
    dtype: str = DTYPE_TEXT         # DTYPE_NUMERIC | DTYPE_TEXT | DTYPE_DATE
    left_source: Optional[str] = None
    right_source: Optional[str] = None

    # value-field comparison tolerances (ignored for keys)
    abs_tol: float = 0.0            # absolute tolerance (numeric/date-days)
    rel_tol: float = 0.0            # relative tolerance as a fraction, e.g. 0.01 = 1%
    text_fuzzy_threshold: Optional[float] = None  # 0-100; if set, text compared fuzzily
    casefold_text: bool = True     # value-field text compared case-insensitively

    # aggregation when a key repeats within one side (value fields only)
    agg: str = AGG_SUM

    def source_for(self, side: str) -> Optional[str]:
        return self.left_source if side == "left" else self.right_source


@dataclass
class NormalizationConfig:
    trim_whitespace: bool = True
    collapse_internal_whitespace: bool = True
    casefold_keys: bool = True          # case-insensitive key matching
    null_tokens: Sequence[str] = ("", "na", "n/a", "nan", "none", "null", "-")
    drop_exact_duplicates: bool = True
    # numeric parsing
    treat_parentheses_as_negative: bool = True
    strip_currency_symbols: bool = True
    # date parsing
    dayfirst: bool = False


@dataclass
class FuzzyConfig:
    enabled: bool = True
    threshold: float = 90.0            # 0-100 minimum composite-key similarity to accept
    blocking_field: Optional[str] = None  # canonical key field used to bucket candidates
    blocking_prefix_len: int = 0       # if >0 and no blocking_field, block on first N chars
    max_candidates_warn: int = 5_000_000  # warn if the candidate space explodes


# --------------------------------------------------------------------------- #
# Value parsing helpers
# --------------------------------------------------------------------------- #
_CURRENCY_RE = re.compile(r"[^\d\-.,()%]")
_WS_RE = re.compile(r"\s+")


def _is_null(v: Any, null_tokens: Sequence[str]) -> bool:
    if v is None:
        return True
    if isinstance(v, float) and math.isnan(v):
        return True
    if isinstance(v, str) and v.strip().lower() in null_tokens:
        return True
    return False


def parse_number(v: Any, cfg: NormalizationConfig) -> Optional[float]:
    """Robustly coerce a messy cell to a float. Returns None if not parseable."""
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return None
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    s = str(v).strip()
    if s == "":
        return None
    negative = False
    if cfg.treat_parentheses_as_negative and s.startswith("(") and s.endswith(")"):
        negative = True
        s = s[1:-1]
    if cfg.strip_currency_symbols:
        s = _CURRENCY_RE.sub("", s)
    is_pct = s.endswith("%")
    s = s.replace("%", "")
    # remove thousands separators; keep last '.' as decimal
    if s.count(",") and s.count("."):
        s = s.replace(",", "")
    elif s.count(",") and not s.count("."):
        # comma likely decimal or thousands; treat single trailing group as decimal
        if re.match(r"^-?\d{1,3}(,\d{3})+$", s):
            s = s.replace(",", "")
        else:
            s = s.replace(",", ".")
    s = s.replace(" ", "")
    if s in ("", "-", ".", "-."):
        return None
    try:
        num = float(s)
    except ValueError:
        return None
    if negative:
        num = -num
    if is_pct:
        num = num / 100.0
    return num


def parse_date(v: Any, cfg: NormalizationConfig) -> Optional[pd.Timestamp]:
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return None
    try:
        ts = pd.to_datetime(v, dayfirst=cfg.dayfirst, errors="coerce")
    except Exception:
        return None
    if ts is pd.NaT or (isinstance(ts, float) and math.isnan(ts)):
        return None
    return ts


def normalize_text(v: Any, cfg: NormalizationConfig, casefold: bool) -> Optional[str]:
    if _is_null(v, cfg.null_tokens):
        return None
    s = str(v)
    if cfg.trim_whitespace:
        s = s.strip()
    if cfg.collapse_internal_whitespace:
        s = _WS_RE.sub(" ", s)
    if casefold:
        s = s.casefold()
    return s if s != "" else None


# --------------------------------------------------------------------------- #
# Streamline + canonicalize
# --------------------------------------------------------------------------- #
def _clean_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df


def streamline_side(
    frames: List[Tuple[str, pd.DataFrame]],
    fields: List[Field],
    side: str,
    norm: NormalizationConfig,
) -> pd.DataFrame:
    """Union many raw files for one side and coerce each mapped field to its dtype.

    `frames` is a list of (filename, dataframe). Returns a canonical frame whose
    columns are the canonical field names, plus a `_source_file` provenance column.
    """
    key_fields = [f for f in fields if f.role == ROLE_KEY]
    value_fields = [f for f in fields if f.role == ROLE_VALUE]

    pieces: List[pd.DataFrame] = []
    for fname, raw in frames:
        raw = _clean_columns(raw)
        out = pd.DataFrame(index=raw.index)
        for f in fields:
            src = f.source_for(side)
            if src is None or src not in raw.columns:
                out[f.name] = pd.Series([None] * len(raw), index=raw.index, dtype="object")
                continue
            col = raw[src]
            if f.dtype == DTYPE_NUMERIC:
                out[f.name] = col.map(lambda x: parse_number(x, norm))
            elif f.dtype == DTYPE_DATE:
                out[f.name] = col.map(lambda x: parse_date(x, norm))
            else:
                casefold = norm.casefold_keys and f.role == ROLE_KEY
                out[f.name] = col.map(lambda x: normalize_text(x, norm, casefold))
        out["_source_file"] = fname
        pieces.append(out)

    if not pieces:
        cols = [f.name for f in fields] + ["_source_file"]
        return pd.DataFrame(columns=cols)

    combined = pd.concat(pieces, ignore_index=True)

    # drop rows with an entirely-null key (nothing to reconcile on)
    if key_fields:
        key_names = [f.name for f in key_fields]
        combined = combined.dropna(subset=key_names, how="all").reset_index(drop=True)

    if norm.drop_exact_duplicates:
        subset = [f.name for f in fields]
        combined = combined.drop_duplicates(subset=subset).reset_index(drop=True)

    return combined


def _composite_key(df: pd.DataFrame, key_names: List[str]) -> pd.Series:
    def _mk(row) -> str:
        return "|".join("" if pd.isna(row[k]) else str(row[k]) for k in key_names)
    return df.apply(_mk, axis=1) if len(df) else pd.Series([], dtype="object")


def canonicalize(
    df: pd.DataFrame,
    fields: List[Field],
) -> pd.DataFrame:
    """Collapse a streamlined side to one record per composite key.

    Value fields are aggregated per their `agg`. Text/date value fields default
    to FIRST unless overridden. A provenance column keeps the contributing files
    and a `_row_count` records how many raw lines rolled into each key.
    """
    key_fields = [f for f in fields if f.role == ROLE_KEY]
    value_fields = [f for f in fields if f.role == ROLE_VALUE]
    key_names = [f.name for f in key_fields]

    if not len(df):
        cols = key_names + [f.name for f in value_fields] + ["_row_count", "_source_files", "_key"]
        return pd.DataFrame(columns=cols)

    work = df.copy()
    work["_key"] = _composite_key(work, key_names)

    agg_spec: Dict[str, Any] = {}
    for f in value_fields:
        if f.dtype == DTYPE_NUMERIC:
            agg_spec[f.name] = f.agg if f.agg in {
                AGG_SUM, AGG_MEAN, AGG_FIRST, AGG_LAST, AGG_COUNT, AGG_MAX, AGG_MIN
            } else AGG_SUM
        else:
            # text/date default to first value seen
            agg_spec[f.name] = "first"

    # keep the key columns as first-seen representatives (they define the group)
    for f in key_fields:
        agg_spec[f.name] = "first"

    grouped = work.groupby("_key", sort=False, dropna=False)
    out = grouped.agg(agg_spec)
    out["_row_count"] = grouped.size()
    out["_source_files"] = grouped["_source_file"].agg(
        lambda s: ", ".join(sorted(set(map(str, s))))
    )
    out = out.reset_index()
    return out


# --------------------------------------------------------------------------- #
# Matching
# --------------------------------------------------------------------------- #
@dataclass
class MatchPair:
    left_key: str
    right_key: str
    match_type: str        # "exact" | "fuzzy"
    score: float           # 100 for exact


def match_sides(
    left: pd.DataFrame,
    right: pd.DataFrame,
    fuzzy: FuzzyConfig,
    key_fields: List[Field],
) -> Tuple[List[MatchPair], List[str], List[str]]:
    """Return (pairs, unmatched_left_keys, unmatched_right_keys)."""
    left_keys = list(left["_key"]) if len(left) else []
    right_keys = list(right["_key"]) if len(right) else []
    right_set = set(right_keys)

    pairs: List[MatchPair] = []
    matched_left: set = set()
    matched_right: set = set()

    # 1) exact matches
    for k in left_keys:
        if k in matched_left:
            continue
        if k in right_set and k not in matched_right:
            pairs.append(MatchPair(k, k, "exact", 100.0))
            matched_left.add(k)
            matched_right.add(k)

    # 2) fuzzy on residuals
    if fuzzy.enabled:
        res_left = [k for k in left_keys if k not in matched_left]
        res_right = [k for k in right_keys if k not in matched_right]

        blocks = _build_blocks(res_left, res_right, left, right, fuzzy, key_fields)

        candidates: List[Tuple[float, str, str]] = []
        for lkeys, rkeys in blocks:
            for lk in lkeys:
                for rk in rkeys:
                    score = _similarity(lk, rk)
                    if score >= fuzzy.threshold:
                        candidates.append((score, lk, rk))

        # greedy best-first assignment; a key is used at most once
        candidates.sort(key=lambda t: t[0], reverse=True)
        for score, lk, rk in candidates:
            if lk in matched_left or rk in matched_right:
                continue
            pairs.append(MatchPair(lk, rk, "fuzzy", round(score, 2)))
            matched_left.add(lk)
            matched_right.add(rk)

    unmatched_left = [k for k in left_keys if k not in matched_left]
    unmatched_right = [k for k in right_keys if k not in matched_right]
    return pairs, unmatched_left, unmatched_right


def _build_blocks(res_left, res_right, left, right, fuzzy, key_fields):
    """Bucket residual keys to shrink the fuzzy candidate space.

    Blocking avoids the full O(n*m) product. If a blocking field is given, keys
    are grouped by that field's normalized value; else by a key prefix; else one
    global block (with a soft warning left to the caller via candidate counting).
    """
    if fuzzy.blocking_field:
        lmap = dict(zip(left["_key"], left[fuzzy.blocking_field]))
        rmap = dict(zip(right["_key"], right[fuzzy.blocking_field]))
        buckets: Dict[Any, Tuple[list, list]] = {}
        for k in res_left:
            buckets.setdefault(lmap.get(k), ([], []))[0].append(k)
        for k in res_right:
            buckets.setdefault(rmap.get(k), ([], []))[1].append(k)
        return list(buckets.values())

    if fuzzy.blocking_prefix_len > 0:
        n = fuzzy.blocking_prefix_len
        buckets = {}
        for k in res_left:
            buckets.setdefault(k[:n], ([], []))[0].append(k)
        for k in res_right:
            buckets.setdefault(k[:n], ([], []))[1].append(k)
        return list(buckets.values())

    return [(res_left, res_right)]


# --------------------------------------------------------------------------- #
# Comparison / variance
# --------------------------------------------------------------------------- #
@dataclass
class FieldComparison:
    field: str
    dtype: str
    left_value: Any
    right_value: Any
    difference: Optional[float]     # numeric/date-days: left - right
    pct_difference: Optional[float]
    within_tolerance: bool


def _compare_field(f: Field, lval: Any, rval: Any) -> FieldComparison:
    if f.dtype == DTYPE_NUMERIC:
        lv = None if pd.isna(lval) else float(lval)
        rv = None if pd.isna(rval) else float(rval)
        if lv is None and rv is None:
            return FieldComparison(f.name, f.dtype, lv, rv, None, None, True)
        lv0 = 0.0 if lv is None else lv
        rv0 = 0.0 if rv is None else rv
        diff = lv0 - rv0
        pct = (diff / rv0) if rv0 != 0 else (0.0 if diff == 0 else math.inf)
        ok = (abs(diff) <= f.abs_tol) or (f.rel_tol > 0 and abs(pct) <= f.rel_tol)
        return FieldComparison(f.name, f.dtype, lv, rv, diff, pct, bool(ok))

    if f.dtype == DTYPE_DATE:
        lv = None if pd.isna(lval) else pd.Timestamp(lval)
        rv = None if pd.isna(rval) else pd.Timestamp(rval)
        if lv is None and rv is None:
            return FieldComparison(f.name, f.dtype, lv, rv, None, None, True)
        if lv is None or rv is None:
            return FieldComparison(f.name, f.dtype, lv, rv, None, None, False)
        days = (lv - rv).days
        ok = abs(days) <= f.abs_tol
        return FieldComparison(f.name, f.dtype, lv, rv, float(days), None, bool(ok))

    # text
    lv = None if pd.isna(lval) else str(lval)
    rv = None if pd.isna(rval) else str(rval)
    cl = (lv or "").casefold() if f.casefold_text else (lv or "")
    cr = (rv or "").casefold() if f.casefold_text else (rv or "")
    if f.text_fuzzy_threshold is not None and lv is not None and rv is not None:
        ok = _similarity(cl, cr) >= f.text_fuzzy_threshold
    else:
        ok = cl == cr
    return FieldComparison(f.name, f.dtype, lv, rv, None, None, bool(ok))


# --------------------------------------------------------------------------- #
# Orchestrator + result
# --------------------------------------------------------------------------- #
@dataclass
class ReconResult:
    reconciled: pd.DataFrame
    breaks: pd.DataFrame
    unmatched_left: pd.DataFrame
    unmatched_right: pd.DataFrame
    field_variance: pd.DataFrame
    summary: Dict[str, Any]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "summary": self.summary,
            "field_variance": _df_records(self.field_variance),
            "reconciled": _df_records(self.reconciled),
            "breaks": _df_records(self.breaks),
            "unmatched_left": _df_records(self.unmatched_left),
            "unmatched_right": _df_records(self.unmatched_right),
        }


def _df_records(df: pd.DataFrame) -> List[Dict[str, Any]]:
    if df is None or not len(df):
        return []
    safe = df.replace({np.nan: None})
    # stringify timestamps for JSON friendliness
    for c in safe.columns:
        if pd.api.types.is_datetime64_any_dtype(safe[c]):
            safe[c] = safe[c].map(lambda x: None if pd.isna(x) else pd.Timestamp(x).isoformat())
    return safe.to_dict(orient="records")


def reconcile(
    left_frames: List[Tuple[str, pd.DataFrame]],
    right_frames: List[Tuple[str, pd.DataFrame]],
    fields: List[Field],
    norm: Optional[NormalizationConfig] = None,
    fuzzy: Optional[FuzzyConfig] = None,
) -> ReconResult:
    norm = norm or NormalizationConfig()
    fuzzy = fuzzy or FuzzyConfig()

    key_fields = [f for f in fields if f.role == ROLE_KEY]
    value_fields = [f for f in fields if f.role == ROLE_VALUE]
    if not key_fields:
        raise ValueError("At least one key field is required.")

    # streamline -> canonicalize each side
    left_s = streamline_side(left_frames, fields, "left", norm)
    right_s = streamline_side(right_frames, fields, "right", norm)
    left_c = canonicalize(left_s, fields)
    right_c = canonicalize(right_s, fields)

    left_by_key = {r["_key"]: r for _, r in left_c.iterrows()}
    right_by_key = {r["_key"]: r for _, r in right_c.iterrows()}

    pairs, un_l, un_r = match_sides(left_c, right_c, fuzzy, key_fields)

    reconciled_rows: List[Dict[str, Any]] = []
    break_rows: List[Dict[str, Any]] = []
    field_diff_totals: Dict[str, Dict[str, float]] = {
        f.name: {"sum_diff": 0.0, "sum_abs_diff": 0.0, "n_breaks": 0}
        for f in value_fields
    }

    for p in pairs:
        lrow = left_by_key[p.left_key]
        rrow = right_by_key[p.right_key]
        rec: Dict[str, Any] = {"match_type": p.match_type, "match_score": p.score}
        for f in key_fields:
            rec[f.name] = lrow[f.name]
        broke_fields: List[str] = []
        row_ok = True
        for f in value_fields:
            cmp = _compare_field(f, lrow[f.name], rrow[f.name])
            rec[f"{f.name}__left"] = cmp.left_value
            rec[f"{f.name}__right"] = cmp.right_value
            rec[f"{f.name}__diff"] = cmp.difference
            rec[f"{f.name}__pct"] = cmp.pct_difference
            rec[f"{f.name}__ok"] = cmp.within_tolerance
            if f.dtype in (DTYPE_NUMERIC, DTYPE_DATE) and cmp.difference is not None:
                field_diff_totals[f.name]["sum_diff"] += cmp.difference
                field_diff_totals[f.name]["sum_abs_diff"] += abs(cmp.difference)
            if not cmp.within_tolerance:
                row_ok = False
                broke_fields.append(f.name)
                field_diff_totals[f.name]["n_breaks"] += 1
        rec["_left_source_files"] = lrow.get("_source_files")
        rec["_right_source_files"] = rrow.get("_source_files")
        if row_ok:
            reconciled_rows.append(rec)
        else:
            rec["break_fields"] = ", ".join(broke_fields)
            break_rows.append(rec)

    def _unmatched_frame(keys: List[str], canon: pd.DataFrame, by_key) -> pd.DataFrame:
        rows = []
        for k in keys:
            r = by_key[k]
            row = {f.name: r[f.name] for f in key_fields}
            for f in value_fields:
                row[f.name] = r[f.name]
            row["_source_files"] = r.get("_source_files")
            row["_row_count"] = r.get("_row_count")
            rows.append(row)
        return pd.DataFrame(rows)

    reconciled_df = pd.DataFrame(reconciled_rows)
    breaks_df = pd.DataFrame(break_rows)
    un_left_df = _unmatched_frame(un_l, left_c, left_by_key)
    un_right_df = _unmatched_frame(un_r, right_c, right_by_key)

    fv_rows = []
    for f in value_fields:
        t = field_diff_totals[f.name]
        fv_rows.append({
            "field": f.name,
            "dtype": f.dtype,
            "abs_tol": f.abs_tol,
            "rel_tol": f.rel_tol,
            "sum_left_minus_right": round(t["sum_diff"], 6),
            "sum_abs_difference": round(t["sum_abs_diff"], 6),
            "n_breaks": t["n_breaks"],
        })
    field_variance_df = pd.DataFrame(fv_rows)

    n_pairs = len(pairs)
    n_exact = sum(1 for p in pairs if p.match_type == "exact")
    n_fuzzy = n_pairs - n_exact
    n_recon = len(reconciled_df)
    n_break = len(breaks_df)
    denom = n_pairs if n_pairs else 1
    summary = {
        "fuzzy_backend": fuzzy_backend(),
        "left_records": int(len(left_c)),
        "right_records": int(len(right_c)),
        "left_raw_rows": int(len(left_s)),
        "right_raw_rows": int(len(right_s)),
        "matched_pairs": n_pairs,
        "matched_exact": n_exact,
        "matched_fuzzy": n_fuzzy,
        "reconciled": n_recon,
        "breaks": n_break,
        "unmatched_left": int(len(un_left_df)),
        "unmatched_right": int(len(un_right_df)),
        "reconciliation_rate": round(100.0 * n_recon / denom, 2),
        "match_rate_left": round(100.0 * n_pairs / (len(left_c) or 1), 2),
        "match_rate_right": round(100.0 * n_pairs / (len(right_c) or 1), 2),
    }

    return ReconResult(
        reconciled=reconciled_df,
        breaks=breaks_df,
        unmatched_left=un_left_df,
        unmatched_right=un_right_df,
        field_variance=field_variance_df,
        summary=summary,
    )
