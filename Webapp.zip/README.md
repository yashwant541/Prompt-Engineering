# Reconciliation Studio — Dataiku Web App

An advanced, config-driven reconciliation engine and web app. Upload **many
files per side**, streamline them into a canonical `key → value` shape,
match line items across sides (exact + fuzzy with thresholds), compute
variance on the fields you choose, and export a categorized workbook.
**No file storage** — uploads live in memory only and are dropped after the session.

## Pipeline

```
many files (left)   many files (right)
      │                     │
   streamline           streamline        clean columns, coerce numeric/date/text,
      │                     │              parse currency/parentheses/thousands, nulls
  canonicalize         canonicalize        map source cols → canonical fields;
      │                     │              collapse to one record per composite key
      └──────── match ──────┘              exact keys, then fuzzy (rapidfuzz/difflib)
                  │                          with threshold + optional blocking
               compare                       per-field variance vs abs/rel tolerance
                  │
   reconciled │ breaks │ unmatched_left │ unmatched_right │ variance summary
```

## Files

| File | Purpose |
|------|---------|
| `engine/reconcile_engine.py` | The reconciliation engine. Pure Python + pandas/numpy; `rapidfuzz` optional. Framework-agnostic — reusable in a recipe, notebook, or the web app. |
| `webapp/backend.py` | Dataiku **Standard** web app Python backend (Flask routes). In-memory TTL sessions, no disk writes. |
| `webapp/body.html` / `style.css` / `app.js` | The 4-step wizard UI. |
| `tests/test_engine.py` | End-to-end example proving multi-file, cross-named columns, aggregation, fuzzy, and variance behaviour. |

## Key engine concepts

- **Field**: one canonical column shared across both sides, with a `role`
  (`key`/`value`), a `dtype` (`numeric`/`text`/`date`), the source column on
  each side, and — for values — `abs_tol`, `rel_tol`, optional `text_fuzzy_threshold`,
  and an `agg` used when a key repeats within a side.
- **Streamline**: cleans and type-coerces each raw file (handles `$`, `1,200.50`,
  `(1,000)` negatives, `%`, messy dates, null tokens).
- **Canonicalize**: unions a side's files and collapses to one record per
  composite key, aggregating value fields (default `sum`).
- **Match**: exact key equality first, then greedy best-first fuzzy assignment on
  the residuals so a key is never double-matched. Optional **blocking** (by a key
  field or key prefix) keeps fuzzy scalable on large inputs.
- **Compare**: numeric → `left − right`, abs and % diff vs tolerance; date →
  day delta vs tolerance; text → exact or fuzzy (case-insensitive by default).

## No-storage guarantees

- Uploads are parsed straight from the request into pandas — never written to disk
  or to a Dataiku dataset.
- Parsed frames + the last result live in an in-memory dict keyed by a random
  session id, evicted after `SESSION_TTL_SECONDS` (default 1h) or on `/finish`.
- A process restart wipes everything. Previews sent to the browser are capped at
  `MAX_PREVIEW_ROWS`; full data only leaves memory when the user clicks Export.

## Deploy in Dataiku

1. **Code env**: use/create a Python env with `pandas`, `numpy`, `openpyxl`, and
   (recommended) `rapidfuzz`. Without `rapidfuzz` it falls back to stdlib `difflib`.
2. **Make the engine importable**: put `reconcile_engine.py` in the project library
   (*≡ menu → Libraries → `python/`*), **or** paste its contents at the top of the
   web app's Python tab above the routes.
3. **Create the web app**: *Code → Webapps → + New → Standard (HTML/JS/Python)*.
   - Paste `body.html` into **HTML**, `style.css` into **CSS**, `app.js` into **JS**,
     `backend.py` into **Python**.
   - The backend uses the `app` object Dataiku provides; don't redefine it.
4. **Enable the backend** and set the code env on the web app's Settings tab.
5. **Run**. The frontend talks to the backend via `getWebAppBackendUrl(...)`.

## Local sanity check

```bash
python3 tests/test_engine.py    # prints summary + variance, asserts expected behaviour
```

## Scaling notes / next steps

- For very large sides, set a **blocking field** (or prefix length) so fuzzy
  matching doesn't do a full O(n·m) product.
- One-to-many line matching (instead of aggregate-by-key) can be added as an
  alternate canonicalization mode.
- The engine returns plain DataFrames, so the same logic drops into a Dataiku
  **recipe** for scheduled/batch reconciliation if you later want persistence.
