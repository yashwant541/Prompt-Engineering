"""Realistic end-to-end exercise of the reconciliation engine."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pandas as pd
from engine.reconcile_engine import (
    Field, NormalizationConfig, FuzzyConfig, reconcile,
    ROLE_KEY, ROLE_VALUE, DTYPE_NUMERIC, DTYPE_TEXT, AGG_SUM, fuzzy_backend,
)

# LEFT side = our ledger, split across two files, columns named one way
left_file_1 = pd.DataFrame({
    "Inv No":   ["INV-1001", "INV-1002", "INV-1003"],
    "Vendor":   ["Acme Corp.", "Globex LLC", "Initech"],
    "Amount":   ["1,200.50", "$3,400.00", "900"],
})
left_file_2 = pd.DataFrame({
    "Inv No":   ["INV-1003", "INV-1004"],          # 1003 repeats -> should aggregate
    "Vendor":   ["Initech", "Umbrella Co"],
    "Amount":   ["100.00", "5000"],
})

# RIGHT side = vendor statements, different column names, some fuzz + variances
right_file_1 = pd.DataFrame({
    "Reference": ["INV-1001", "INV-1002", "INV-1004"],
    "Supplier":  ["ACME CORP", "Globex  LLC", "Umbrella Company"],  # fuzzy-ish names
    "Total":     ["1200.50", "3400.05", "(4,999.00)"],             # 1002 tiny diff, 1004 break
})
right_file_2 = pd.DataFrame({
    "Reference": ["INV-1003", "INV-9999"],
    "Supplier":  ["Initech", "Ghost Vendor"],       # 9999 exists only on the right
    "Total":     ["1000.00", "42.00"],
})

fields = [
    Field("invoice", role=ROLE_KEY, dtype=DTYPE_TEXT,
          left_source="Inv No", right_source="Reference"),
    Field("vendor", role=ROLE_VALUE, dtype=DTYPE_TEXT,
          left_source="Vendor", right_source="Supplier",
          text_fuzzy_threshold=85.0),
    Field("amount", role=ROLE_VALUE, dtype=DTYPE_NUMERIC,
          left_source="Amount", right_source="Total",
          abs_tol=0.10, rel_tol=0.0, agg=AGG_SUM),
]

result = reconcile(
    left_frames=[("ledger_jan.csv", left_file_1), ("ledger_feb.csv", left_file_2)],
    right_frames=[("stmt_a.csv", right_file_1), ("stmt_b.csv", right_file_2)],
    fields=fields,
    norm=NormalizationConfig(casefold_keys=True),
    fuzzy=FuzzyConfig(enabled=True, threshold=90.0),
)

print("fuzzy backend:", fuzzy_backend())
print("\n=== SUMMARY ===")
for k, v in result.summary.items():
    print(f"  {k}: {v}")

print("\n=== FIELD VARIANCE ===")
print(result.field_variance.to_string(index=False))

print("\n=== RECONCILED (within tolerance) ===")
print(result.reconciled[["invoice", "match_type", "amount__left", "amount__right", "amount__diff"]].to_string(index=False))

print("\n=== BREAKS ===")
cols = ["invoice", "break_fields", "amount__left", "amount__right", "amount__diff", "vendor__left", "vendor__right"]
print(result.breaks[cols].to_string(index=False))

print("\n=== UNMATCHED LEFT ===")
print(result.unmatched_left.to_string(index=False))
print("\n=== UNMATCHED RIGHT ===")
print(result.unmatched_right.to_string(index=False))

# --- assertions: the reconciliation must behave as designed ---
s = result.summary
# INV-1003 aggregated on left: 900 + 100 = 1000, right = 1000 -> reconciled
recon_keys = set(result.reconciled["invoice"])
assert "inv-1003" in recon_keys, "aggregated key should reconcile"
assert "inv-1001" in recon_keys, "exact equal amount should reconcile"
# INV-1002 differs by 0.05 (<0.10 tol) -> reconciled
assert "inv-1002" in recon_keys, "within-tolerance diff should reconcile"
# INV-1004: left 5000 vs right 4999 -> break
break_keys = set(result.breaks["invoice"])
assert "inv-1004" in break_keys, "out-of-tolerance amount should break"
# INV-9999 only on right; nothing 1005+ on left
assert s["unmatched_right"] == 1
assert set(result.unmatched_right["invoice"]) == {"inv-9999"}
assert s["unmatched_left"] == 0
print("\nALL ASSERTIONS PASSED")
